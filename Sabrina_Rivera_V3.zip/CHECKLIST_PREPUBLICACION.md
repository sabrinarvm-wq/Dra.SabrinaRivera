# CHECKLIST PREPUBLICACIÓN — V2

## Identidad
- [ ] Confirmar teléfono/WhatsApp definitivo.
- [ ] Añadir fotografía profesional real de la Dra. Sabrina.
- [ ] Confirmar email profesional.
- [ ] Confirmar dominio.

## Perfil profesional
- [ ] Universidad.
- [ ] Residencia / sede.
- [ ] Certificación de Consejo.
- [ ] Formación o alta especialidad en endoscopia.
- [ ] Sociedades médicas.
- [ ] Hospitales donde cuenta con privilegios/credencialización.

## Conversión
- [ ] Google Business Profile.
- [ ] Mapa real.
- [ ] Reseñas verificadas de Google.
- [ ] Horarios.
- [ ] Aseguradoras realmente manejadas.
- [ ] GA4 / Tag Manager.

## Legal
- [ ] Aviso de privacidad definitivo.
- [ ] Aviso de publicidad / requisitos aplicables.
- [ ] Autorización de uso de logos institucionales, si se muestran.
