# MEDICIÓN DE CONVERSIONES

El sitio ya dispara eventos a `window.dataLayer` cuando alguien hace clic en botones de contacto.

Evento:
- `contact_cta`

Campos:
- `action`
- `page`
- `path`

Al publicar:
1. Instalar Google Tag Manager o GA4.
2. Crear una conversión para `contact_cta`.
3. Separar conversiones por:
   - header_whatsapp
   - hero_whatsapp
   - floating_whatsapp
   - procedure_whatsapp
   - contact_whatsapp
4. Conectar Google Search Console.
5. Añadir llamadas telefónicas como conversión separada.
6. Usar UTMs en campañas pagadas.
